// Write a program that displays the name of students whose CGPA is 3.5 or above.

#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    ifstream readData;
    readData.open("data.txt");
    char RegistrationNumber[20];
    char FirstName[20];
    char lastName[20];
    char Program[20];
    float CGPA = 0;
    int ContactNumber = 0;
    int data = 0;
    if (!readData)
    {
        cout << " FILE IS NOT PRESENT ";
    }
    else
    {
        cout << "RegistrationNumber        FirstName        lastName       Program      CGPA    ContactNumber ";
        cout << endl;
        while (!readData.eof())
        {
            readData >> RegistrationNumber;
            readData >> FirstName;
            readData >> lastName;
            readData >> Program;
            readData >> CGPA;
            readData >> ContactNumber;
            readData >> data;
            if (CGPA >= 3.5)
            {
                cout << RegistrationNumber << "  ";
                cout << FirstName << "  ";
                cout << lastName << "  ";
                cout << Program << "  ";
                cout << CGPA << "  ";
                cout << ContactNumber << "  ";
                cout << data << "  ";
                cout << endl;
            }
        }
    }

    return 0;
}