#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int readData1(ifstream &readData, string *MaritalStatus, string *EmpName, int *Salary);
int main()
{
    ifstream readData;
    readData.open("employe.txt");
    int index = 0;
    int max = 0;
    int min = 0;
    float avg = 0;
    float sum = 0;
    int whatIsIndexNumber = 0;
    string whatIsIndexName = "ilyas";
    char name[20];
    string MaritalStatus[20];
    string single = "single";
    int Salary[20];
    string EmpName[20];
    if (!readData)
    {
        cout << " FILE IS NOT PRESENT ";
    }
    else
    {
        index = readData1(readData, MaritalStatus, EmpName, Salary);
        max = Salary[0];
        min = Salary[0];
        cout << "1. Find the Name of The Person who is getting highest salary.\n";
        for (int i = 0; i < index; i++)
        {
            if (Salary[i] > max)
            {
                whatIsIndexNumber = i;
            }
        }
        cout << EmpName[whatIsIndexNumber] << "  ";
        cout << Salary[whatIsIndexNumber] << "  ";
        cout << MaritalStatus[whatIsIndexNumber] << "  ";
        cout << endl;
        whatIsIndexNumber = 0;
        cout << "2. Find the Name of The Person who is getting lowest salary.\n";
        for (int i = 0; i < index; i++)
        {
            if (Salary[i] < min)
            {
                whatIsIndexNumber = i;
            }
        }
        cout << EmpName[whatIsIndexNumber] << "  ";
        cout << Salary[whatIsIndexNumber] << "  ";
        cout << MaritalStatus[whatIsIndexNumber] << "  ";
        cout << endl;
        whatIsIndexNumber = 0;
        cout << "3- Print the total number of employees whore married..\n";
        for (int i = 0; i < index; i++)
        {
            if (MaritalStatus[i] != single)
            {
                cout << EmpName[i] << "  ";
                cout << Salary[i] << "  ";
                cout << MaritalStatus[i] << "  ";
                cout << endl;
            }
        }
        whatIsIndexNumber = 0;
        cout << "4- Print the name of employees who are single..\n";
        for (int i = 0; i < index; i++)
        {
            if (MaritalStatus[i] == single)
            {
                cout << EmpName[i] << "  ";
                cout << Salary[i] << "  ";
                cout << MaritalStatus[i] << "  ";
                cout << endl;
            }
        }
        cout << "5. Print the Average salary of all employees..\n";
        for (int i = 0; i < index; i++)
        {
            sum += Salary[i];
        }
        avg = sum / index;
        cout << " AVERAGE OF SALARY IS THIS : " << avg;
        cout << endl;
        cout << "6. Print the name of Employees Whose Salary is greater than your name is save in whatisindexNumber  variable";

        for (int i = 0; i < index; i++)
        {
            if (EmpName[i] == whatIsIndexName)
            {
                whatIsIndexNumber = i;
            }

            if (Salary[i] > Salary[whatIsIndexNumber])
            {
                cout << EmpName[i] << "  ";
                cout << Salary[i] << "  ";
                cout << MaritalStatus[i] << "  ";
                cout << endl;
            }
        }
        cout << endl;
        cout << "7. Print the name of Employees Whose Salary is less than your name is save ˘ A˘˙I..\n";

        for (int i = 0; i < index; i++)
        {

            if (EmpName[i] == whatIsIndexName)
            {
                whatIsIndexNumber = i;
            }

            if (Salary[i] < Salary[whatIsIndexNumber])
            {
                cout << EmpName[i] << "  ";
                cout << Salary[i] << "  ";
                cout << MaritalStatus[i] << "  ";
                cout << endl;
            }
        }
        cout << endl;
        cout << "8.  Search and display the information of whatisname is you save in whatisindexnamevariable.\n";

        for (int i = 0; i < index; i++)
        {

            if (EmpName[i] == whatIsIndexName)
            {
                cout << EmpName[i] << "  ";
                cout << Salary[i] << "  ";
                cout << MaritalStatus[i] << "  ";
                cout << endl;
            }
        }
    }

    return 0;
}
int readData1(ifstream &readData, string *MaritalStatus, string *EmpName, int *Salary)
{
    int i = 0;
    while (!readData.eof())
    {

        readData >> EmpName[i];

        readData >> Salary[i];
        readData >> MaritalStatus[i];
        i++;
    }
    return i;
}