#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main()
{
    ifstream readData;
    readData.open("employe.txt");

    char MaritalStatus[20];
    int Salary = 0;
    int contact = 0;
    int DeptId = 0;
    string EmpJoiningDate;
    char EmpName[20];
    int empId = 0;
    if (!readData)
    {
        cout << " FILE IS NOT PRESENT ";
    }
    else
    {
        while (!readData.eof())
        {
            readData >> empId;
            readData >> EmpName;
            readData >> EmpJoiningDate;
            readData >> DeptId;
            readData >> contact;
            readData >> Salary;
            readData >> MaritalStatus;

            if (Salary > 150000)
            {
                cout << empId << "  ";
                cout << EmpName << "  ";
                cout << EmpJoiningDate << "  ";
                cout << DeptId << "  ";
                cout << contact << "  ";
                cout << Salary << "  ";
                cout << MaritalStatus << "  ";
                cout << endl;
                cout << endl;
                cout << endl;
            }
        }
    }

    return 0;
}