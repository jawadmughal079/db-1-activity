// Write a program to take inputs the following attributes and write on a file (StudentInfo.csv)
// 1. RegistrationNumber
// 2. First Name
// 3. Last Name
// 4. Program
// 5. CGPA
// 6. ContactNumber
// StudentInfo file should be like below:
// 1 Regis t ra tionNumbe r , F i r s t Name, L a s t Name, Program , CGPA, ContactNumber
// 2 L1f11BSCS0001 , Sadia , Khan , BSCS , 3.27 , 03321234123
// 3 L1f11BSCS0021 , Shanya , Khan , BSCS , 3.77 , 03321234213
// 4 L1f11BSCS0031 , Goree , Khan , BSCS , 3.57 , 03321234143
// 5 L1f11BSCS0041 , Jemayma , Khan , BSCS , 3.85 , 03321234223
// 6 L1f11BSCS0022 , Samandar , Khan , BSCS , 3.97 , 03321234542
// 7 L1f11BSCS0025 , Reham , Khan , BSCS , 2.47 , 03321234213

#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    ofstream writeData;
    writeData.open("data.txt", ios::app);
    char RegistrationNumber[20];
    char FirstName[20];
    char lastName[20];
    char Program[20];
    float CGPA=0;
    int ContactNumber=0;
    int data = 0;
    cout << " HOW MANY DATA YOU WANT TO STORE : ";
    cin >> data;
    writeData << "RegistrationNumber        FirstName        lastName       Program      CGPA    ContactNumber ";
    writeData << endl;
    for (int i = 0; i < data; i++)
    {
        cout << " Enter a RegistrationNumber of [" << i + 1 << "] student ";
        cin >> RegistrationNumber;
        writeData << RegistrationNumber;
        writeData << " ";
        cout << " Enter a FirstName of [" << i + 1 << "] student ";
        cin >> FirstName;
        writeData << FirstName;
        writeData << " ";
        cout << " Enter a lastName of [" << i + 1 << "] student ";
        cin >> lastName;
        writeData << lastName;
        writeData << " ";
        cout << " Enter a Program of [" << i + 1 << "] student ";
        cin >> Program;
        writeData << Program;
        writeData << " ";
        cout << " Enter a CGPA of [" << i + 1 << "] student ";
        cin >> CGPA;
        if (CGPA > 4)
        {
            while (CGPA <= 4)
            {
                cout << " Enter a CGPA of [" << i + 1 << "] student again because your cgpa greater than 4 ";
                cin >> CGPA;
            }
        }

        writeData << CGPA;
        writeData << " ";
        cout << " Enter a ContactNumber of [" << i + 1 << "] student ";
        cin >> ContactNumber;
        writeData << ContactNumber;
        writeData << " ";

        writeData << endl;
    }

    return 0;
}